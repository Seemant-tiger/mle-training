train module
============

.. automodule:: train
   :members:
   :undoc-members:
   :show-inheritance:
