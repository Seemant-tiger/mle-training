.. MLE_Training documentation master file, created by
   sphinx-quickstart on Sun Jun 20 16:42:02 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to MLE_Training's documentation!
========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   ingest_data
   train
   score
   logs
   modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
