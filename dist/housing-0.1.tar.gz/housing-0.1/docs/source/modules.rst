src
===

.. toctree::
   :maxdepth: 4
   
   ingest_data
   train
   score

